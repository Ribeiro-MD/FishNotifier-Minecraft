package com.example.fishnotifier;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1109;
import net.minecraft.class_1536;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
/**
 * Este mod lê todas as logs da pasta .minecraft, ao instalá-lo está ciente que tudo
 * será lido e processado...TUDO.
 */
public class FishNotifierClient implements ClientModInitializer {

    private static final TermoConfig TERMO_CARANGUEJO =
            new TermoConfig("LusíadasCraft ➤ Pescaste um Caranguejo!", "🦀", "fishnotifier.overlay.caught", 3, class_3417.field_14833);

     static final TermoConfig TERMO_MORDIDA =
            new TermoConfig(null, "🐟", "fishnotifier.overlay.generic", 2, class_3417.field_14793.comp_349());

    private static final List<TermoConfig> TERMOS = new CopyOnWriteArrayList<>(List.of(
            TERMO_CARANGUEJO
    ));


    private record TermoConfig(String termo, String icone, String chaveSubtitulo, int numeroDeToques, class_3414 som) {}

    // Intervalo entre cada toque em milissegundos (1 segundo = 1000 milissegundos).
    private static final long INTERVALO_MS = 500;

    // Tempo de estágio (em ticks (20 ticks = 1 segundo))
    private static final int DURACAO_FADE_IN = 5;
    private static final int DURACAO_ESTADIA = 40;
    private static final int DURACAO_FADE_OUT = 10;

    // Se a bóia descer mais depressa do que isto (Y negativo) não é naturaç = é mordida no anzol
    private static final double LIMIAR_VELOCIDADE_MORDIDA = -0.2;

    // Volume do som (1.0 = normal, podes subir para 2.0, 3.0 para ficar bem mais alto, o normal é 1.0f)
    private static final float VOLUME = 2.0f;

    private static final ScheduledExecutorService agendador = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "termwatch-agendador");
        t.setDaemon(true);
        return t;
    });

    // Guardam o estado da bóia entre ticks, para só notificar uma vez
    private static class_1536 boiaAnterior = null;
    private static boolean jaNotificouEstaMordida = false;
    private static boolean prontaParaDetetarMordida = false;
    private static int ticksParadaSeguidos = 0;

    // Quantos ticks a boia fica em repouso pra começar a contar o timer da ação do /title
    private static final int TICKS_ATE_ARMAR = 15;
    // Quão perto de 0 a velocidade tem de estar para contar como estando a flutuar/em repouso na água.
    private static final double LIMIAR_PARADA = 0.03;

    @Override
    public void onInitializeClient() {
        // Primeira leitura (chat) — só apanha o caranguejo agora
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            verificarTexto(message.getString());
            return true;
        });

        // Segunda leitura (logs)
        LogTermAppender.registrar(FishNotifierClient::verificarTexto);

        // Primeira leitura da cana: observa a bóia da cana de pesca a cada tick
        ClientTickEvents.END_CLIENT_TICK.register(FishNotifierClient::verificarMordida);
    }

    private static void verificarTexto(String texto) {
        if (texto == null) return;
        String textoLower = texto.toLowerCase(Locale.ROOT);
        for (TermoConfig termo : TERMOS) {
            if (textoLower.contains(termo.termo().toLowerCase(Locale.ROOT))) {
                notificar(termo);
                break;
            }
        }
    }

    private static void verificarMordida(class_310 client) {
        if (client.field_1724 == null) {
            reiniciarEstado();
            return;
        }

        class_1536 boia = client.field_1724.field_7513;

        // Sem cana lançada: reinicia o estado, fundalmental para repetir o ciclo
        if (boia == null) {
            reiniciarEstado();
            return;
        }

        // Nova bóia lançada (cana relançada): reinicia o estado.
        if (boia != boiaAnterior) {
            boiaAnterior = boia;
            jaNotificouEstaMordida = false;
            prontaParaDetetarMordida = false;
            ticksParadaSeguidos = 0;
        }

        double velocidadeY = boia.method_18798().field_1351;

        if (!prontaParaDetetarMordida) {
            // Ainda a "assentar" na água (ignora o splash do lançamento da cana)
            if (Math.abs(velocidadeY) < LIMIAR_PARADA) {
                ticksParadaSeguidos++;
                if (ticksParadaSeguidos >= TICKS_ATE_ARMAR) {
                    prontaParaDetetarMordida = true;
                }
            } else {
                ticksParadaSeguidos = 0;
            }
            return;
        }

        if (!jaNotificouEstaMordida && velocidadeY < LIMIAR_VELOCIDADE_MORDIDA) {
            jaNotificouEstaMordida = true;
            notificar(TERMO_MORDIDA);
        }
    }

    private static void reiniciarEstado() {
        boiaAnterior = null;
        jaNotificouEstaMordida = false;
        prontaParaDetetarMordida = false;
        ticksParadaSeguidos = 0;
    }

    private static void notificar(TermoConfig termo) {
        class_310 client = class_310.method_1551();
        if (client == null) return;

        // Mostra o título (ícone) e o subtítulo (tipo de pesca)
        client.execute(() -> {
            if (client.field_1705 != null) {
                client.field_1705.method_34001(DURACAO_FADE_IN, DURACAO_ESTADIA, DURACAO_FADE_OUT);
                client.field_1705.method_34004(class_2561.method_43470(termo.icone()));
                client.field_1705.method_34002(class_2561.method_43471(termo.chaveSubtitulo()));
            }
        });

        //ciclo for pra tocar o sino
        for (int i = 0; i < termo.numeroDeToques(); i++) {
            agendador.schedule(
                    () -> client.execute(() -> tocarSino(termo.som())),
                    i * INTERVALO_MS,
                    TimeUnit.MILLISECONDS
            );
        }
    }

    private static void tocarSino(class_3414 som) {
        class_310 client = class_310.method_1551();
        if (client != null && client.method_1483() != null && client.field_1724 != null) {
            client.method_1483().method_4873(
                    new class_1109(
                            som,
                            class_3419.field_15250,
                            VOLUME,
                            2.4f,                                 // Quanto maior o número, maior o som. O normal é 1!
                            class_5819.method_43047(),
                            client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()
                    )
            );
        }
    }
}